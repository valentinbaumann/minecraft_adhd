#
# DEPRECATED: use mineturtle.py
#

from mineturtle import *
from mcpi.block import *
