#
# DEPRECATED: use mine.py
#

#
# Code by Alexander Pruss and under the MIT license
#

from mcpi.minecraft import *
from mcpi.entity import *
from mcpi.block import *
from mcpi.settings import *
from math import *
from mcpi.vec3 import *