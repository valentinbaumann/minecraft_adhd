from mine import *
from sys import argv
mc = Minecraft()
mc.postToChat(mc.player.getTilePos())
