All the scripts here are supposed to be dual Python 2/3 compatible.
