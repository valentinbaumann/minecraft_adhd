unzip $APPDATA/.minecraft/versions/1.10.2/1.10.2.jar 'assets/minecraft/textures/blocks/*.*'
python getcolors.py > colordictionary.py
